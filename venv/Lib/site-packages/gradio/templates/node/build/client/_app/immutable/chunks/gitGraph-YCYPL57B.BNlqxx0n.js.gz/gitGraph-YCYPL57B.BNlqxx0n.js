import { G, f } from "./mermaid-parser.core.BQ8j9bTb.js";
export {
  G as GitGraphModule,
  f as createGitGraphServices
};
