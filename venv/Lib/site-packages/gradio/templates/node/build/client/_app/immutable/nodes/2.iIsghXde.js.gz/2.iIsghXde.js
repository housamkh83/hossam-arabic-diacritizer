import { X, _ } from "../chunks/2.PUtrIOKS.js";
export {
  X as component,
  _ as universal
};
