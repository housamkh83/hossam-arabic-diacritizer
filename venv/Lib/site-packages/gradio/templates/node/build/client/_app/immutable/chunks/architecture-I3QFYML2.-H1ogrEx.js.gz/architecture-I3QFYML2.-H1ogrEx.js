import { A, e } from "./mermaid-parser.core.BQ8j9bTb.js";
export {
  A as ArchitectureModule,
  e as createArchitectureServices
};
