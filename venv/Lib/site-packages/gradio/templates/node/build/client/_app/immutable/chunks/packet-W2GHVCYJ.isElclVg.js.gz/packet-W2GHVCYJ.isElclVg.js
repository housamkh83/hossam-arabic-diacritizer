import { P, a } from "./mermaid-parser.core.BQ8j9bTb.js";
export {
  P as PacketModule,
  a as createPacketServices
};
